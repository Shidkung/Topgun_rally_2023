from fastapi import APIRouter 
import streamlit as st
import requests


st.title("Streamlit App")