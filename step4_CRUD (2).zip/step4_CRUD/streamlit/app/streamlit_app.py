# Import necessary libraries
from collections import namedtuple
import altair as alt
import pandas as pd
import streamlit as st
from pymongo import MongoClient
from bson.objectid import ObjectId
import plotly.express as px

# MongoDB connection
MONGO_DETAILS = "mongodb://tesarally:contestor@mongoDB:27017"
client = MongoClient(MONGO_DETAILS)
db2 = client["mockupdata"]
waterdata = db2["waterdata"]

# Fetch data from MongoDB
water = waterdata.find()
waterlist = list(water)
data = pd.DataFrame.from_dict(waterlist)

# Add custom CSS for styling
st.markdown(
    """
    <style>
        body {
            color: #fff; /* Text color is set to white for better readability on a dark background */
            background-color: #000; /* Black background */
            font-family: 'Arial', sans-serif;
        }
        .stApp {
            max-width: 1200px;
            margin: auto;
        }
        h1, h2, h3 {
            color: #0068c9;
        }
        p {
            font-size: 18px;
            margin-bottom: 20px;
        }
        hr {
            border: 1px solid #0068c9;
        }
        .widget-label {
            color: #0068c9;
            font-size: 18px;
            margin-top: 10px;
            margin-bottom: 5px;
        }
        .widget-select {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #0068c9;
            color: #000;
            background-color: #fff;
        }
        .widget-radio {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            margin-top: 10px;
            margin-bottom: 20px;
        }
        .widget-radio label {
            color: #fff;
            font-size: 16px;
        }
    </style>
    """,
    unsafe_allow_html=True
)

# Header
st.title("Water Data Analysis Dashboard")
st.header("Explore and visualize water data over the years.")

# Display DataFrame using Streamlit
#st.subheader("Raw Data")
#st.dataframe(data)

# Multi-select for years
selected_years = st.multiselect("Select Years", list(range(2016, 2024)), default=list(range(2016, 2024)))

selectable_columns = [col for col in data.columns if col not in ["_id", "Name", "Date", "Month", "Year"]]

# Multi-select for columns
selected_columns = st.multiselect("Select Columns to Show", selectable_columns, default=["WaterDataFront", "WaterDataBack", "WaterDrainRate"])


# Filter data based on the selected years
filtered_data = data[data["Year"].isin(selected_years)]

# Check if there is data to display
if not filtered_data.empty and selected_columns:

    
    # Sum the selected columns for each selected year
    sum_data = filtered_data.groupby("Year")[selected_columns].sum().reset_index()
    # Melt the DataFrame for Altair plotting
    melted_data = pd.melt(sum_data, id_vars=["Year"], var_name="Column", value_name="Sum")
    # ... (previous code remains unchanged)

# Create a button to toggle between Graph, Chart, and Metric
st.markdown("<div>Select Visualization Type:</div>", unsafe_allow_html=True)
# Apply custom CSS for horizontal alignment
display_option = st.radio("", ["Graph","Chart"], key="select_viz_type", index=0, format_func=lambda x: f"{x}")

if display_option == "Graph":

    # Display Line chart using Plotly Express
    st.subheader("Line Chart - Sum of Selected Columns by Year")
    fig = px.line(melted_data, x='Year', y='Sum', color='Column', markers=True)
    st.plotly_chart(fig)

    # Display Scatter Plot using Plotly Express
    st.subheader("Scatter Plot - Sum of Selected Columns by Year")
    fig = px.scatter(melted_data, x='Year', y='Sum', color='Column')
    st.plotly_chart(fig)
elif display_option == "Chart":
        # Display Bar chart using Altair with a smaller size
    st.subheader("Bar Chart - Sum of Selected Columns by Year")
    st.altair_chart(alt.Chart(melted_data)
        .mark_bar(color='#0068c9', opacity=0.7)
        .encode(x='Year:O', y=alt.Y('Sum:Q', title='Sum'), color='Column:N')
        .properties(height=300, width=400))  # Adjust the height and width as needed

    # Add more chart options based on your requirements
    # For example, you can create additional line charts, area charts, etc.

    # Display Line Chart using Altair
    
    # You can add more chart types here...

else:
    st.warning("Please select a visualization type.")
# ... (rest of the code remains unchanged
        # Display st.markdown for each year with smaller size
# Display Metric visualization using st.metric in a horizontal row
st.subheader("Water Data Metrics by Year - Metric Visualization")

for year in selected_years:
        # Get the data for the selected year
        year_data = filtered_data[filtered_data["Year"] == year]

        # Display st.markdown for each year with smaller size
        st.markdown(
            f"<div style='font-size: 20px; margin-top: 20px;'>"
            f"<strong>Year {year} Metrics:</strong> "
            f"Front: {year_data['WaterDataFront'].values[0]}, "
            f"Back: {year_data['WaterDataBack'].values[0]}, "
            f"Drain Rate: {year_data['WaterDrainRate'].values[0]}"
            f"</div>",
            unsafe_allow_html=True
        )
        # Horizontal line as a divider
        st.markdown("<hr>", unsafe_allow_html=True)
